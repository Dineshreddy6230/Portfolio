import React, { useState, useEffect } from 'react';
import { Moon, Sun, Github, Linkedin, Mail, ExternalLink, Code, Database, Cloud, Wrench, GraduationCap, MapPin } from 'lucide-react';

function App() {
  const [darkMode, setDarkMode] = useState(false);

  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  const toggleDarkMode = () => {
    setDarkMode(!darkMode);
  };

  const skills = {
    "Programming Languages": ["Python", "Java", "TypeScript", "JavaScript", "C++", "HTML", "CSS"],
    "Frontend Development": ["React", "HTML5", "CSS3", "JavaScript ES6+", "Responsive Design"],
    "Cloud & DevOps": ["AWS (EC2, VPC, CloudWatch)", "Docker", "Kubernetes", "Git", "Bitbucket", "CI/CD"],
    "Tools & IDEs": ["VS Code", "IntelliJ", "Eclipse", "Android Studio", "FileZilla", "Putty"],
    "Methodologies": ["Agile", "Waterfall", "OOP", "Microservices", "Monolithic Architecture"]
  };

  const projects = [
    {
      title: "Scalable Web-Based Group Chat Application",
      description: "Created a group chat application deployed on AWS with EC2 instances, implementing auto-scaling and load balancer for high availability.",
      technologies: ["HTML", "CSS", "JavaScript", "AWS EC2", "Auto-scaling", "Load Balancer"],
      type: "Cloud Deployment"
    },
    {
      title: "Medical Chatbot",
      description: "Developed an intelligent chatbot to provide health-related suggestions, assisting users with symptom determination and treatment advice.",
      technologies: ["Python", "Natural Language Processing", "Machine Learning"],
      type: "AI/ML"
    },
    {
      title: "VM Performance Monitoring System",
      description: "Set up EC2 instances and communication channels between VMs within a VPC, using CloudWatch to monitor performance metrics.",
      technologies: ["AWS EC2", "VPC", "CloudWatch", "Performance Monitoring"],
      type: "Cloud Infrastructure"
    },
    {
      title: "Cloud-Deployed Group Chat Application",
      description: "Developed and deployed a scalable group chat application using AWS services, tested locally and optimized for high traffic scenarios.",
      technologies: ["AWS EC2", "Cloud Deployment", "Scalability Testing"],
      type: "Full Stack"
    }
  ];

  return (
    <div className={`min-h-screen transition-colors duration-300 ${darkMode ? 'dark' : ''}`}>
      <div className="bg-white dark:bg-gray-900 text-gray-900 dark:text-white">
        {/* Header with Dark Mode Toggle */}
        <header className="fixed top-0 w-full bg-white/80 dark:bg-gray-900/80 backdrop-blur-md z-50 border-b border-gray-200 dark:border-gray-700">
          <div className="container mx-auto px-6 py-4 flex justify-between items-center">
            <h1 className="text-xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
              Dinesh Reddy Y
            </h1>
            <button
              onClick={toggleDarkMode}
              className="p-2 rounded-lg bg-gray-100 dark:bg-gray-800 hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors"
            >
              {darkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
            </button>
          </div>
        </header>

        {/* Hero Section */}
        <section className="pt-20 pb-16 px-6">
          <div className="container mx-auto text-center">
            <div className="max-w-4xl mx-auto">
              <h1 className="text-5xl md:text-7xl font-bold mb-6 bg-gradient-to-r from-blue-600 via-purple-600 to-teal-600 bg-clip-text text-transparent animate-pulse">
                Dinesh Reddy Y
              </h1>
              <p className="text-xl md:text-2xl text-gray-600 dark:text-gray-300 mb-8">
                Software Engineer
              </p>
              <p className="text-lg text-gray-500 dark:text-gray-400 mb-12 max-w-2xl mx-auto">
                Passionate about building scalable, high-quality software with a focus on clean code, efficient design, and exceptional user experiences.
              </p>
              <div className="flex flex-wrap justify-center gap-4">
                <a
                  href="https://github.com/Dineshreddy583"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 bg-gray-900 dark:bg-white text-white dark:text-gray-900 px-6 py-3 rounded-lg hover:scale-105 transition-transform"
                >
                  <Github className="w-5 h-5" />
                  GitHub
                </a>
                <a
                  href="https://www.linkedin.com/in/dinesh-reddy-yeddula-460317356/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 bg-blue-600 text-white px-6 py-3 rounded-lg hover:scale-105 transition-transform"
                >
                  <Linkedin className="w-5 h-5" />
                  LinkedIn
                </a>
              </div>
            </div>
          </div>
        </section>

        {/* About Section */}
        <section className="py-16 px-6 bg-gray-50 dark:bg-gray-800">
          <div className="container mx-auto">
            <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">About Me</h2>
            <div className="max-w-4xl mx-auto">
              <div className="bg-white dark:bg-gray-900 rounded-2xl p-8 shadow-lg">
                <p className="text-lg text-gray-600 dark:text-gray-300 leading-relaxed mb-6">
                  I am a motivated and detail-oriented <span className="font-semibold text-blue-600 dark:text-blue-400">Software Engineer</span> with a strong foundation in data structures, 
                  algorithms, and system-level programming. Proficient in Java, C++, and modern web technologies including React and TypeScript.
                </p>
                <p className="text-lg text-gray-600 dark:text-gray-300 leading-relaxed mb-6">
                  I have extensive experience in multi-platform development, performance optimization, and concurrency. My expertise spans from 
                  creating responsive, user-friendly frontend interfaces to building robust backend systems and cloud infrastructure.
                </p>
                <p className="text-lg text-gray-600 dark:text-gray-300 leading-relaxed">
                  I am passionate about building scalable, high-quality software with a focus on clean code, efficient design, and delivering 
                  exceptional user experiences that make a real impact.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Skills Section */}
        <section className="py-16 px-6">
          <div className="container mx-auto">
            <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">Technical Skills</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
              {Object.entries(skills).map(([category, skillList], index) => {
                const icons = [Code, Database, Cloud, Wrench, GraduationCap];
                const Icon = icons[index % icons.length];
                return (
                  <div key={category} className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-lg hover:shadow-xl transition-shadow">
                    <div className="flex items-center gap-3 mb-4">
                      <Icon className="w-6 h-6 text-blue-600 dark:text-blue-400" />
                      <h3 className="text-xl font-semibold">{category}</h3>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {skillList.map((skill) => (
                        <span
                          key={skill}
                          className="bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200 px-3 py-1 rounded-full text-sm"
                        >
                          {skill}
                        </span>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </section>

        {/* Education Section */}
        <section className="py-16 px-6 bg-gray-50 dark:bg-gray-800">
          <div className="container mx-auto">
            <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">Education</h2>
            <div className="max-w-4xl mx-auto">
              <div className="space-y-8">
                <div className="bg-white dark:bg-gray-900 rounded-xl p-8 shadow-lg">
                  <div className="flex items-start gap-4">
                    <GraduationCap className="w-8 h-8 text-purple-600 dark:text-purple-400 mt-1" />
                    <div className="flex-1">
                      <h3 className="text-2xl font-bold mb-2">Master's in Software Engineering</h3>
                      <div className="flex items-center gap-2 text-gray-600 dark:text-gray-300 mb-2">
                        <MapPin className="w-4 h-4" />
                        <span>Blekinge Institute of Technology, Sweden</span>
                      </div>
                      <p className="text-gray-500 dark:text-gray-400">
                        Advanced studies in software architecture, system design, and development methodologies
                      </p>
                    </div>
                  </div>
                </div>
                <div className="bg-white dark:bg-gray-900 rounded-xl p-8 shadow-lg">
                  <div className="flex items-start gap-4">
                    <GraduationCap className="w-8 h-8 text-blue-600 dark:text-blue-400 mt-1" />
                    <div className="flex-1">
                      <h3 className="text-2xl font-bold mb-2">Bachelor's in Computer Science</h3>
                      <div className="flex items-center gap-2 text-gray-600 dark:text-gray-300 mb-2">
                        <MapPin className="w-4 h-4" />
                        <span>Blekinge Institute of Technology, Sweden</span>
                      </div>
                      <p className="text-gray-500 dark:text-gray-400">
                        Foundation in computer science principles, algorithms, and programming fundamentals
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Projects Section */}
        <section className="py-16 px-6">
          <div className="container mx-auto">
            <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">Featured Projects</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-6xl mx-auto">
              {projects.map((project, index) => (
                <div key={index} className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-lg hover:shadow-xl transition-all hover:scale-105">
                  <div className="flex items-center gap-2 mb-3">
                    <span className="bg-gradient-to-r from-blue-600 to-purple-600 text-white px-3 py-1 rounded-full text-sm">
                      {project.type}
                    </span>
                  </div>
                  <h3 className="text-xl font-bold mb-3">{project.title}</h3>
                  <p className="text-gray-600 dark:text-gray-300 mb-4">{project.description}</p>
                  <div className="flex flex-wrap gap-2">
                    {project.technologies.map((tech) => (
                      <span
                        key={tech}
                        className="bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 px-2 py-1 rounded text-sm"
                      >
                        {tech}
                      </span>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Contact Section */}
        <section className="py-16 px-6 bg-gray-50 dark:bg-gray-800">
          <div className="container mx-auto text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-8">Get In Touch</h2>
            <p className="text-lg text-gray-600 dark:text-gray-300 mb-12 max-w-2xl mx-auto">
              I'm always interested in new opportunities and collaborations. Let's connect and discuss how we can work together!
            </p>
            <div className="flex flex-wrap justify-center gap-6">
              <a
                href="https://github.com/Dineshreddy583"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-3 bg-white dark:bg-gray-900 text-gray-900 dark:text-white px-6 py-4 rounded-xl shadow-lg hover:shadow-xl transition-all hover:scale-105"
              >
                <Github className="w-6 h-6" />
                <span className="font-medium">GitHub</span>
                <ExternalLink className="w-4 h-4" />
              </a>
              <a
                href="https://www.linkedin.com/in/dinesh-reddy-yeddula-460317356/"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-3 bg-blue-600 text-white px-6 py-4 rounded-xl shadow-lg hover:shadow-xl transition-all hover:scale-105"
              >
                <Linkedin className="w-6 h-6" />
                <span className="font-medium">LinkedIn</span>
                <ExternalLink className="w-4 h-4" />
              </a>
              <a
                href="mailto:dineshreddy583@gmail.com"
                className="flex items-center gap-3 bg-teal-600 text-white px-6 py-4 rounded-xl shadow-lg hover:shadow-xl transition-all hover:scale-105"
              >
                <Mail className="w-6 h-6" />
                <span className="font-medium">Email</span>
              </a>
            </div>
          </div>
        </section>

        {/* Footer */}
        <footer className="py-8 px-6 border-t border-gray-200 dark:border-gray-700">
          <div className="container mx-auto text-center">
            <p className="text-gray-600 dark:text-gray-400">
              © 2025 Dinesh Reddy Y. Built with React & Tailwind CSS.
            </p>
          </div>
        </footer>
      </div>
    </div>
  );
}

export default App;